from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    daily_limit = models.IntegerField(default=5)
    used_today = models.IntegerField(default=0)
    is_premium = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username
    

class QuizQuestion(models.Model):
    SUBJECT_CHOICES = [
        ('math', 'Math'),
        ('science', 'Science'),
        ('english', 'English'),
    ]

    subject = models.CharField(max_length=20, choices=SUBJECT_CHOICES)

    question = models.CharField(max_length=255)
    option1 = models.CharField(max_length=100)
    option2 = models.CharField(max_length=100)
    option3 = models.CharField(max_length=100)
    option4 = models.CharField(max_length=100)
    answer = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.subject} - {self.question}"

class CurrentAffair(models.Model):
    title = models.CharField(max_length=255)
    notes = models.TextField()

    question = models.CharField(max_length=255)
    option1 = models.CharField(max_length=100)
    option2 = models.CharField(max_length=100)
    option3 = models.CharField(max_length=100)
    option4 = models.CharField(max_length=100)
    answer = models.CharField(max_length=100)

    date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.title

class QuizQuestion(models.Model):
    subject = models.CharField(max_length=50)

    question = models.CharField(max_length=255)

    option1 = models.CharField(max_length=100)
    option2 = models.CharField(max_length=100)
    option3 = models.CharField(max_length=100)
    option4 = models.CharField(max_length=100)

    answer = models.CharField(max_length=100)

    def __str__(self):
        return self.question