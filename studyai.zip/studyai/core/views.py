from django.contrib.auth.models import User
import re
from core.models import CurrentAffair
from django.contrib.auth import authenticate, login, logout, decorators
from django.shortcuts import render, redirect
import feedparser
from django.contrib.auth.decorators import login_required
from .models import QuizQuestion



def home(request):
    articles = CurrentAffair.objects.all().order_by('-id')[:5]

    return render(request, "home.html", {
        "articles": articles
    })

def signup(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        User.objects.create_user(username=username, password=password)
        return redirect('login')

    return render(request, "signup.html")


def user_login(request):
    if request.method == "POST":
        user = authenticate(
            username=request.POST.get("username"),
            password=request.POST.get("password")
        )
        if user:
            login(request, user)
            return redirect('/')
    return render(request, "login.html")

@decorators.login_required
def home(request):
    result = ""
    profile = request.user.userprofile
    is_limit_reached = False

    if request.method == "POST":

        # limit check
        if not profile.is_premium and profile.used_today >= profile.daily_limit:
            is_limit_reached = True
            return render(request, "home.html", {
                "result": "⚠️ Daily limit reached!",
                "is_limit_reached": True
            })

        query = request.POST.get("query")
        mode = request.POST.get("mode")

        # Dummy response (AI baad me)
        if mode == "homework":
            if profile.is_premium:
                result = f"📘 Full Step-by-Step Solution: {query}"
            else:
                result = f"📘 Short Answer: {query} (Upgrade for full solution)"
        else:
            if profile.is_premium:
                result = f"📝 Detailed Notes: {query}"
            else:
                result = f"📝 Basic Notes: {query} (Upgrade for full notes)"

        profile.used_today += 1
        profile.save()

    return render(request, "home.html", {
        "result": result,
        "is_limit_reached": is_limit_reached
    })

def user_logout(request):
    logout(request)
    return redirect('login')

@decorators.login_required
def upgrade(request):
    if request.method == "POST":
        profile = request.user.userprofile
        profile.is_premium = True
        profile.save()
        return redirect('/')

    return render(request, "upgrade.html")

@decorators.login_required
def quiz(request):
    profile = request.user.userprofile
    subject = request.GET.get("subject")

    questions = []

    # GET request (subject select hone ke baad)
    if subject:
        if profile.is_premium:
            questions = QuizQuestion.objects.filter(subject=subject)
        else:
            questions = QuizQuestion.objects.filter(subject=subject)[:5]

    score = 0

    # POST request (quiz submit hone ke baad)
    if request.method == "POST":
        subject = request.POST.get("subject")
        questions = QuizQuestion.objects.filter(subject=subject)

        for q in questions:
            selected = request.POST.get(str(q.id))
            if selected == q.answer:
                score += 1

        return render(request, "quiz.html", {
            "questions": questions,
            "score": score,
            "submitted": True,
            "subject": subject
        })

    return render(request, "quiz.html", {
        "questions": questions,
        "subject": subject
    })

def generate_quiz(subject):
    prompt = f"""
    Create 5 MCQ questions for {subject}.
    Format:
    Question, 4 options, correct answer.
    Simple for students.
    """

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content

@decorators.login_required
def quiz(request):
    subject = request.GET.get("subject")
    quiz_data = None

    if subject:
        quiz_data = generate_quiz(subject)

    return render(request, "quiz.html", {
        "quiz_data": quiz_data,
        "subject": subject
    })

def clean_html(raw_html):
    import re
    clean_text = re.sub('<.*?>', '', raw_html)
    clean_text = clean_text.replace('&nbsp;', ' ')
    return clean_text


def make_exam_note(text):
    # Short ko thoda explain banane ke liye
    lines = text.split('.')

    points = []
    for line in lines:
        if line.strip():
            points.append(f"👉 {line.strip()}.")

    # Extra exam angle add
    points.append("📌 Exam Point: Yeh current affairs exams me important ho sakta hai.")

    return "\n".join(points)


@login_required
def current_affairs(request):
    url = "https://news.google.com/rss/search?q=india+current+affairs"
    feed = feedparser.parse(url)

    articles = []

    for entry in feed.entries[:10]:

        # 🔥 fallback logic (IMPORTANT)
        summary = ""

        if hasattr(entry, "summary"):
            summary = entry.summary
        elif hasattr(entry, "description"):
            summary = entry.description
        elif hasattr(entry, "title"):
            summary = entry.title  # last fallback

        clean_summary = clean_html(summary)

        # 🔥 agar still empty ho
        if not clean_summary.strip():
            clean_summary = "No details available for this news."

        
        detailed = f"👉 {clean_summary}\n\n📌 Exam Point: Important for exams."

        articles.append({
            "title": entry.title,
            "summary": detailed,
            "published": entry.get("published", "")
        })

    return render(request, "current_affairs.html", {
        "articles": articles
    })

@login_required
def current_affairs(request):
    articles = CurrentAffair.objects.all().order_by('-date')

    return render(request, "current-affairs.html", {
        "articles": articles
    })

def mock_tests(request):
    return render(request, "mock-tests.html")


def notes(request):
    return render(request, "notes.html")


def daily_quiz(request):
    return render(request, "daily-quiz.html")


def leaderboard(request):
    return render(request, "leaderboard.html")


def premium(request):
    return render(request, "premium.html")

from .models import QuizQuestion
from django.shortcuts import render

def quiz(request):

    questions = QuizQuestion.objects.all()
    score = 0
    submitted = False
    results = []
    error = None   # 👈 add this

    if request.method == "POST":

        # 🔥 👉 YAHAN ADD KARNA HAI (सबसे पहले)
        for q in questions:
            if not request.POST.get(str(q.id)):
                error = "⚠️ Please select all questions"
                return render(request, "quiz.html", {
                    "questions": questions,
                    "error": error
                })

        # 👇 अगर सब answered हैं तभी आगे चलेगा
        submitted = True

        for q in questions:
            selected = request.POST.get(str(q.id))
            is_correct = (selected == q.answer)

            if is_correct:
                score += 1

            results.append({
                "question": q,
                "selected": selected,
                "correct": q.answer,
                "is_correct": is_correct
            })

    total = questions.count()
    status = "PASS ✅" if score >= total * 0.5 else "FAIL ❌"

    return render(request, "quiz.html", {
        "questions": questions,
        "score": score,
        "submitted": submitted,
        "results": results,
        "total": total,
        "status": status,
        "error": error   # 👈 important
    })



