from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.user_login, name='login'),
    path('signup/', views.signup, name='signup'),
    path('logout/', views.user_logout),
    path('upgrade/', views.upgrade, name='upgrade'),
    path('quiz/', views.quiz, name='quiz'),
    path('current-affairs/', views.current_affairs, name='current_affairs'),
    path('mock-tests/', views.mock_tests, name='mock_tests'),
    path('notes/', views.notes, name='notes'),
    path('daily-quiz/', views.daily_quiz, name='daily_quiz'),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
    path('premium/', views.premium, name='premium'),
]