from django.contrib import admin
from .models import UserProfile
from .models import CurrentAffair
from .models import QuizQuestion

admin.site.register(QuizQuestion)

admin.site.register(UserProfile)


admin.site.register(CurrentAffair)